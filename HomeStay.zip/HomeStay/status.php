<?php
session_start();
include 'farmhouse_admin/config/config.php';

$admin = new Admin();
$conn = $admin->getConn();

$user_email = $_SESSION['user_email'] ?? '';

// 🧹 Deletion Logic
if (isset($_GET['delete_id'])) {
  $delete_id = $_GET['delete_id'];

  // Get related farmhouse_id
  $stmt = $conn->prepare("SELECT farmhouse_id FROM book WHERE id = ? AND email = ?");
  $stmt->bind_param("is", $delete_id, $user_email);
  $stmt->execute();
  $stmt->bind_result($farmhouse_id);
  $stmt->fetch();
  $stmt->close();

  // Delete feedback related to that farmhouse_id and user
  if ($farmhouse_id) {
    $deleteFeedback = $conn->prepare("DELETE FROM feedback WHERE farmhouse_id = ? AND email = ?");
    $deleteFeedback->bind_param("is", $farmhouse_id, $user_email);
    $deleteFeedback->execute();
    $deleteFeedback->close();
  }

  // Delete the booking record
  $deleteBooking = $conn->prepare("DELETE FROM book WHERE id = ? AND email = ?");
  $deleteBooking->bind_param("is", $delete_id, $user_email);
  $deleteBooking->execute();
  $deleteBooking->close();

  header("Location: status.php");
  exit();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <title>Booking Status - FindMyHomeStay</title>
  <style>
    * { margin: 0; padding: 0; box-sizing: border-box; }
    body { font-family: Arial, sans-serif; background: #f4f6f8; }
    header { background-color: #2e7d32; color: white; padding: 1rem 2rem; display: flex; justify-content: space-between; align-items: center; }
    .logo { font-size: 1.5rem; font-weight: bold; }
    nav a { color: white; margin-left: 20px; text-decoration: none; font-weight: bold; transition: color 0.3s; }
    nav a:hover { color: #c8e6c9; }
    h2 { text-align: center; margin: 2rem 0 1rem; color: #2e7d32; }
    table { width: 95%; margin: auto; border-collapse: collapse; background: white; box-shadow: 0 0 10px rgba(0,0,0,0.1); }
    th, td { padding: 12px 16px; border: 1px solid #ddd; text-align: center; }
    th { background-color: #2e7d32; color: white; }
    tr:nth-child(even) { background-color: #f2f2f2; }
    tr:hover { background-color: #e8f5e9; }
    footer { text-align: center; padding: 1rem; margin-top: 2rem; background-color: #fff; color: #666; font-size: 0.9rem; }
    button { padding: 6px 12px; background-color: #4caf50; color: white; border: none; border-radius: 4px; cursor: pointer; }
    button:hover { background-color: #388e3c; }
    .delete-btn { background-color: #d32f2f; margin-left: 8px; }
    .delete-btn:hover { background-color: #b71c1c; }

    @media (max-width: 768px) {
      header { flex-direction: column; align-items: flex-start; }
      nav { margin-top: 0.5rem; }
      nav a { display: inline-block; margin-left: 0; margin-right: 15px; }
    }
  </style>
</head>
<body>

<header>
  <div class="logo">FindMyHomeStay</div>
  <nav>
    <a href="homee.html">Home</a>
  </nav>
</header>

<h2>Your Booking Status</h2>

<table>
  <thead>
    <tr>
      <th>Full Name</th>
      <th>Email</th>
      <th>Phone Number</th>
      <th>Number of Guests</th>
      <th>Check-in Date</th>
      <th>Check-out Date</th>
      <th>Status</th>
      <th>Actions</th>
    </tr>
  </thead>
  <tbody>
    <?php
    if (!$user_email) {
      echo "<tr><td colspan='8'>Please make a booking to view status.</td></tr>";
    } else {
      $stmt = $conn->prepare("SELECT * FROM book WHERE email = ? ORDER BY id DESC");
      $stmt->bind_param("s", $user_email);
      $stmt->execute();
      $result = $stmt->get_result();

      if ($result->num_rows > 0) {
        while ($row = $result->fetch_assoc()) {
          $status_color = 'orange';
          if ($row['status'] == 'Accepted') $status_color = 'green';
          else if ($row['status'] == 'Rejected') $status_color = 'red';

          echo "<tr>
            <td>" . htmlspecialchars($row['full_name']) . "</td>
            <td>{$row['email']}</td>
            <td>{$row['phone']}</td>
            <td>{$row['guests']}</td>
            <td>{$row['checkin_date']}</td>
            <td>{$row['checkout_date']}</td>
            <td style='color: $status_color;'>{$row['status']}</td>
            <td>
              <a href='feedback.php?farmhouse_id={$row["farmhouse_id"]}'><button>Feedback</button></a>
              <a href='status.php?delete_id={$row["id"]}' onclick=\"return confirm('Are you sure you want to delete this booking and feedback?');\">
                <button class='delete-btn'>Delete</button>
              </a>
            </td>
          </tr>";
        }
      } else {
        echo "<tr><td colspan='8'>No bookings found for your email.</td></tr>";
      }
    }
    ?>
  </tbody>
</table>

<footer>
  &copy; 2025 FindMyHomeStay. All rights reserved.
</footer>

</body>
</html>
