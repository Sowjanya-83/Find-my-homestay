<?php
class Admin {
    private $conn;

    public function __construct() {
        $this->conn = new mysqli("localhost", "root", "", "homestay");
        if ($this->conn->connect_error) {
            die("Database connection failed: " . $this->conn->connect_error);
        }
    }

    public function getConnection() {
        return $this->conn;
    }

    public function cud($query, $msg) {
        return $this->conn->query($query);
    }

    // ❌ Plain-text login (no hashing)
    public function login($usernameOrEmail, $password) {
        $stmt = $this->conn->prepare("SELECT * FROM user WHERE Username = ? OR email = ?");
        $stmt->bind_param("ss", $usernameOrEmail, $usernameOrEmail);
        $stmt->execute();
        $result = $stmt->get_result();

        if ($result->num_rows === 1) {
            $row = $result->fetch_assoc();
            // 🔓 Compare plain password directly (insecure)
            if ($password === $row['Password']) {
                return $row;
            }
        }

        return false;
    }
}
?>
