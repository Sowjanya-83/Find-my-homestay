<?php
session_start();
error_reporting(E_ALL);
ini_set('display_errors', 1);
include 'config.php';

$user = new Admin();

if ($_SERVER["REQUEST_METHOD"] === "POST") {
    $usernameOrEmail = $_POST['email'];
    $password = $_POST['Password'];

    $userData = $user->login($usernameOrEmail, $password);

    if ($userData) {
        $_SESSION['user_email'] = $userData['email'];
        header("Location: ../homee.html");
        exit();
    } else {
        echo "<script>alert('Invalid email or password'); window.location.href='../loginn.html';</script>";
    }
}
?>
