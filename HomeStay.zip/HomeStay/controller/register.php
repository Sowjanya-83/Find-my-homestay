<?php
error_reporting(E_ALL);
ini_set('display_errors', 1);
include 'config.php';

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $admin = new Admin();

    $Username = $_POST['Username'];
    $email = $_POST['email'];
    $Password = $_POST['Password'];
    $Confirmpassword = $_POST['Confirmpassword'];

    if ($Password !== $Confirmpassword) {
        echo "<script>alert('Passwords do not match'); window.history.back();</script>";
        exit;
    }

    // ❌ Saving plain password directly (not secure)
    $query = "INSERT INTO user (Username, email, Password, Confirmpassword) 
              VALUES ('$Username', '$email', '$Password', '$Confirmpassword')";

    $stmt = $admin->cud($query, "insert");

    if ($stmt) {
        echo "<script>alert('Registered Successfully'); window.location='../loginn.html';</script>";
    } else {
        echo "<script>alert('Registration Failed'); window.history.back();</script>";
    }
}
?>
