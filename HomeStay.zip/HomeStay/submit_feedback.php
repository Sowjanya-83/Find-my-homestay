<?php
session_start();
include 'farmhouse_admin/config/config.php';

$admin = new Admin();
$conn = $admin->getConn();

// ✅ Get POST data
$full_name = $_POST['full_name'];
$email = $_POST['email'];
$message = $_POST['message'];

// ✅ Get farmhouse_id from the form (not from session)
$farmhouse_id = $_POST['farmhouse_id'] ?? 0;

if ($farmhouse_id == 0) {
    echo "<script>alert('Farmhouse not found.'); window.location='status.php';</script>";
    exit;
}

// ✅ Get admin_id using farmhouse_id
$stmt = $conn->prepare("SELECT admin_id FROM farmhouses WHERE id = ?");
$stmt->bind_param("i", $farmhouse_id);
$stmt->execute();
$result = $stmt->get_result();
$row = $result->fetch_assoc();
$admin_id = $row ? $row['admin_id'] : 0;

if ($admin_id == 0) {
    echo "<script>alert('Admin not found.'); window.location='status.php';</script>";
    exit;
}

// ✅ Insert feedback
$insert = $conn->prepare("INSERT INTO feedback (farmhouse_id, admin_id, full_name, email, message) VALUES (?, ?, ?, ?, ?)");
$insert->bind_param("iisss", $farmhouse_id, $admin_id, $full_name, $email, $message);

if ($insert->execute()) {
    echo "<script>alert('Thank you for your feedback!'); window.location='status.php';</script>";
} else {
    echo "<script>alert('Feedback failed to save.'); window.history.back();</script>";
}
?>
