<?php
$farmhouse_id = isset($_GET['id']) ? (int) $_GET['id'] : 0;

?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0"/>
  <title>Book a Home Stay | FindMyHomeStay</title>
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
  <style>
    :root {
      --primary-color: #28a745;
      --accent-color: #218838;
      --light-bg: #f4f6f8;
      --white: #fff;
      --text-dark: #333;
    }
    * {
      box-sizing: border-box;
      margin: 0;
      padding: 0;
    }
    body {
      font-family: Arial, sans-serif;
      background-color: var(--light-bg);
      color: var(--text-dark);
      line-height: 1.6;
    }
    header {
      background-color: var(--primary-color);
      color: var(--white);
      padding: 1rem 1.5rem;
      display: flex;
      align-items: center;
      justify-content: space-between;
      flex-wrap: wrap;
    }
    nav {
      display: flex;
      gap: 30px;
    }
    nav a {
      color: #fff;
      text-decoration: none;
      font-size: 1.1rem;
      padding: 6px 12px;
      border-radius: 5px;
      transition: background 0.3s;
    }
    nav a:hover {
      background: #00c853;
    }
    .container {
      max-width: 600px;
      margin: 2rem auto;
      padding: 1.5rem;
      background-color: var(--white);
      border-radius: 8px;
      box-shadow: 0 4px 10px rgba(0, 0, 0, 0.05);
    }
    h2 {
      text-align: center;
      margin-bottom: 1.5rem;
      color: var(--primary-color);
    }
    form label {
      display: block;
      margin-bottom: 0.5rem;
      font-weight: bold;
    }
    form input {
      width: 100%;
      padding: 0.75rem;
      margin-bottom: 1.25rem;
      border: 1px solid #ccc;
      border-radius: 5px;
      font-size: 1rem;
    }
    .brand-title {
      font-size: 2rem;
      font-weight: bold;
    }
    button {
      width: 100%;
      padding: 0.75rem;
      background-color: var(--primary-color);
      border: none;
      color: white;
      font-size: 1.1rem;
      border-radius: 5px;
      cursor: pointer;
      transition: background-color 0.3s ease;
    }
    button:hover {
      background-color: var(--accent-color);
    }
    footer {
      text-align: center;
      padding: 1rem;
      background-color: #fff;
      font-size: 0.9rem;
      color: #666;
      margin-top: 2rem;
    }
    @media (max-width: 600px) {
      header {
        flex-direction: column;
        align-items: flex-start;
      }
    }
  </style>
</head>
<body>

  <header>
    <div class="brand-title">FindMyHomeStay</div>
    <nav>
      <a href="homee.html">Home</a>
      <a href="book.php">Book</a>
      <a href="status.php">Status</a>
    </nav>
  </header>

  <div class="container">
    <h2>Book Your Home Stay</h2>
    <form action="submit_booking.php" method="POST">
      <input type="hidden" name="farmhouse_id" value="<?php echo htmlspecialchars($farmhouse_id); ?>" />
      <input type="text" name="full_name" placeholder="Full Name" required />
      <input type="email" name="email" placeholder="Email Address" required />
      <input type="tel" name="phone" placeholder="Phone Number" required />
      <input type="number" name="guests" placeholder="Number of Guests" required />
      <input type="date" name="checkin_date" required />
      <input type="date" name="checkout_date" required />
      <button type="submit">Book Now</button>
    </form>
  </div>

  <footer>
    &copy; 2025 FindMyHomeStay. All rights reserved.
  </footer>

</body>
</html>
