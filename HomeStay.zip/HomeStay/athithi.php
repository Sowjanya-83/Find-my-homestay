<?php
// Include database config
include 'farmhouse_admin/config/config.php';
$admin = new Admin();
$conn = $admin->getConn();

// Get homestay ID from URL
$id = isset($_GET['id']) ? intval($_GET['id']) : 0;

if ($id <= 0) {
  echo "<h2 style='text-align:center;'>Invalid homestay ID.</h2>";
  exit();
}

// Fetch homestay details
$sql = "SELECT * FROM farmhouses WHERE id = $id";
$result = $conn->query($sql);

if ($result->num_rows === 0) {
  echo "<h2 style='text-align:center;'>Homestay not found.</h2>";
  exit();
}

$row = $result->fetch_assoc();

$name = htmlspecialchars($row['name']);
$location = htmlspecialchars($row['location']);
$description = htmlspecialchars($row['description']);
$image = htmlspecialchars($row['image']);
$images = [
  htmlspecialchars($row['image1']),
  htmlspecialchars($row['image2']),
  htmlspecialchars($row['image3']),
  htmlspecialchars($row['image4'])
];
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0"/>
  <title><?php echo $name; ?> | <?php echo $location; ?></title>
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
  <style>
    /* --- Your full CSS from earlier --- */
    /* It's already included correctly. No need to change this part. */
    /* The styling is same as your version above. */
    :root {
      --primary-color: #1f4037;
      --secondary-color: #99f2c8;
      --accent-color: #28a745;
      --bg-light: #f4f4f4;
      --text-color: #333;
      --white: #fff;
    }

    body {
      margin: 0;
      font-family: 'Segoe UI', sans-serif;
      background-color: var(--bg-light);
      color: var(--text-color);
    }

    header {
      background: linear-gradient(135deg, #1f4037, #76b852);
      color: var(--white);
      padding: 30px 20px;
      display: flex;
      justify-content: space-between;
      align-items: center;
      flex-wrap: wrap;
    }

    header h1 {
      font-size: 2.5rem;
      margin: 0;
    }

    header p {
      margin-top: 5px;
      font-size: 1.1rem;
    }

    nav {
      display: flex;
      gap: 20px;
      margin-top: 10px;
    }

    nav a {
      color: #fff;
      text-decoration: none;
      font-size: 18px;
      padding: 8px 14px;
      border-radius: 5px;
      transition: background-color 0.3s, transform 0.2s;
    }

    nav a:hover {
      background-color:green;
      transform: scale(1.05);
    }

    .gallery-section {
      background-color: var(--bg-light);
      padding: 60px 20px;
    }

    .gallery-section h2 {
      text-align: center;
      color: green;
      font-size: 2.2rem;
      margin-bottom: 30px;
    }

    .gallery {
      display: flex;
      overflow-x: auto;
      gap: 20px;
      padding: 10px 0;
      scroll-snap-type: x mandatory;
    }

    .gallery::-webkit-scrollbar {
      height: 8px;
    }

    .gallery::-webkit-scrollbar-thumb {
      background-color: #bbb;
      border-radius: 10px;
    }

    .gallery-item {
      flex: 0 0 auto;
      scroll-snap-align: start;
      width: 300px;
      height: 200px;
      border-radius: 12px;
      overflow: hidden;
      box-shadow: 0 6px 15px rgba(0,0,0,0.1);
      background: white;
    }

    .gallery-item img {
      width: 100%;
      height: 100%;
      object-fit: cover;
      display: flex;
      transition: transform 0.4s ease;
    }

    .gallery-item:hover img {
      transform: scale(1.05);
    }

    section {
      background-color: white;
      margin: 30px auto;
      padding: 30px;
      border-radius: 10px;
      max-width: 1000px;
      box-shadow: 0 4px 10px rgba(0,0,0,0.05);
    }

    .about h2 {
      color: green;
      font-size: 2rem;
      margin-bottom: 15px;
    }

    .about p {
      font-size: 1.15rem;
      line-height: 1.8;
    }

    .facilities-section {
      background-color: var(--bg-light);
    }

    .facilities-grid {
      display: grid;
      grid-template-columns: repeat(auto-fit, minmax(220px, 1fr));
      gap: 25px;
      margin-top: 30px;
    }

    .facility-card {
      background: white;
      border-radius: 10px;
      padding: 20px;
      text-align: center;
      box-shadow: 0 4px 8px rgba(0,0,0,0.1);
      transition: transform 0.3s ease;
    }

    .facility-card:hover {
      transform: translateY(-5px);
    }

    .facility-icon {
      font-size: 2rem;
      color: var(--accent-color);
      margin-bottom: 10px;
    }

    .facility-card h3 {
      margin-bottom: 10px;
      color: var(--primary-color);
    }

    .btn {
      display: inline-block;
      background-color: white;
      color: green;
      padding: 12px 24px;
      border-radius: 5px;
      font-size: 1rem;
      font-weight: bold;
      text-decoration: none;
      transition: background-color 0.3s;
    }

    .btn:hover {
      background-color:#28a745;
    }

    .cta-section {
      text-align: center;
      background-color:rgb(6, 95, 48);
      color: white;
      padding: 50px 20px;
      border-radius: 10px;
      margin: 40px auto;
      max-width: 1000px;
    }

    .cta-section h2 {
      font-size: 2.2rem;
      margin-bottom: 15px;
    }

    .section-title {
      color: green;
      font-size:1.5rem;
      text-align: center;
    }

    footer {
      background-color: transparent;
      color: #666;
      text-align: center;
      padding: 15px;
      margin-top: 30px;
    }
  </style>
</head>

<body>
  <header>
    <div>
      <h1><?php echo $name; ?></h1>
      <p>Your nature getaway in <?php echo $location; ?></p>
    </div>
    <nav>
      <a href="udupi.html">Home</a>
      <a href="status.html">Status</a>
    </nav>
  </header>

  <section class="gallery-section">
    <h2>Our Homestay Views</h2>
    <div class="gallery">
      <?php
        if (!empty($image)) {
          echo '<div class="gallery-item"><img src="farmhouse_admin/admin/uploads/' . $image . '" alt="Main Image"></div>';
        }
        foreach ($images as $img) {
          if (!empty($img)) {
            echo '<div class="gallery-item"><img src="farmhouse_admin/admin/uploads/' . $img . '" alt="Gallery Image"></div>';
          }
        }
      ?>
    </div>
  </section>

  <section class="about">
    <h2>About the Homestay</h2>
    <p><?php echo nl2br($description); ?></p>
  </section>

  <section class="facilities-section">
    <div class="section-title">
      <h2 style="text-align:center;">Our Facilities</h2>
    </div>
    <div class="facilities-grid">
      <div class="facility-card"><div class="facility-icon"><i class="fas fa-wifi"></i></div><h3>Free Wi-Fi</h3><p>High-speed internet throughout the property</p></div>
      <div class="facility-card"><div class="facility-icon"><i class="fas fa-utensils"></i></div><h3>Complimentary Breakfast</h3><p>Delicious local flavors to start your day</p></div>
      <div class="facility-card"><div class="facility-icon"><i class="fas fa-fire"></i></div><h3>Campfire & BBQ</h3><p>Evenings made magical on request</p></div>
      <div class="facility-card"><div class="facility-icon"><i class="fas fa-tree"></i></div><h3>Plantation Walks</h3><p>Explore the estate with guided nature tours</p></div>
      <div class="facility-card"><div class="facility-icon"><i class="fas fa-bolt"></i></div><h3>Power Backup</h3><p>24/7 electricity for uninterrupted comfort</p></div>
      <div class="facility-card"><div class="facility-icon"><i class="fas fa-broom"></i></div><h3>Clean Rooms</h3><p>Hygienic and well-maintained accommodation</p></div>
      <div class="facility-card"><div class="facility-icon"><i class="fas fa-water"></i></div><h3>Hot Water</h3><p>Always available in all bathrooms</p></div>
      <div class="facility-card"><div class="facility-icon"><i class="fas fa-parking"></i></div><h3>Parking</h3><p>Secure parking space for all guests</p></div>
    </div>
  </section>

  <section class="cta-section" id="book">
    <h2>Ready for Your Perfect Getaway?</h2>
    <p>Book your stay now and experience the magic of <?php echo $location; ?> with our warm hospitality.</p>
    <a href="book.php?id=<?php echo $id; ?>" class="btn">Book Now <i class="fas fa-calendar-check"></i></a>

  </section>

  <footer>
    <p>&copy; 2025 Find My HomeStay. All rights reserved.</p>
  </footer>
</body>
</html>
