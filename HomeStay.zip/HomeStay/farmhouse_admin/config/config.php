<?php
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}


class Admin {
    private $conn;
    
    public function __construct() {
        $host = 'localhost';
        $username = 'root';
        $password = '';
        $database = 'homestay';
        
        $this->conn = new mysqli($host, $username, $password, $database);
        
        if ($this->conn->connect_error) {
            die("Connection failed: " . $this->conn->connect_error);
        }
    }
    
    public function getConn() {
        return $this->conn;
    }
    
    public function login($email, $password) {
        $stmt = $this->conn->prepare("SELECT id, name, password FROM admins WHERE email = ?");
        $stmt->bind_param("s", $email);
        $stmt->execute();
        $result = $stmt->get_result();
        
        if ($result->num_rows == 1) {
            $admin = $result->fetch_assoc();
            if (password_verify($password, $admin['password'])) {
                $_SESSION['admin_id'] = $admin['id'];
                $_SESSION['admin_name'] = $admin['name'];
                return true;
            }
        }
        return false;
    }
    
    public function logout() {
        session_destroy();
        return true;
    }
    
    public function isLoggedIn() {
        return isset($_SESSION['admin_id']);
    }
    
    public function getAdminData($id) {
        $stmt = $this->conn->prepare("SELECT id, name, email FROM admins WHERE id = ?");
        $stmt->bind_param("i", $id);
        $stmt->execute();
        return $stmt->get_result()->fetch_assoc();
    }
    
    public function getDashboardStats($admin_id) {
        $stats = [];
        
        // Total farmhouses
        $stmt = $this->conn->prepare("SELECT COUNT(*) as total FROM farmhouses WHERE admin_id = ?");
        $stmt->bind_param("i", $admin_id);
        $stmt->execute();
        $stats['total_farmhouses'] = $stmt->get_result()->fetch_assoc()['total'];
        
        // Total bookings
        $stmt = $this->conn->prepare("
            SELECT COUNT(*) as total 
            FROM bookings b 
            JOIN farmhouses f ON b.farmhouse_id = f.id 
            WHERE f.admin_id = ?
        ");
        $stmt->bind_param("i", $admin_id);
        $stmt->execute();
        $stats['total_bookings'] = $stmt->get_result()->fetch_assoc()['total'];
        
        // Pending bookings
        $stmt = $this->conn->prepare("
            SELECT COUNT(*) as total 
            FROM bookings b 
            JOIN farmhouses f ON b.farmhouse_id = f.id 
            WHERE f.admin_id = ? AND b.status = 'Pending'
        ");
        $stmt->bind_param("i", $admin_id);
        $stmt->execute();
        $stats['pending_bookings'] = $stmt->get_result()->fetch_assoc()['total'];
        
        // Confirmed bookings
        $stmt = $this->conn->prepare("
            SELECT COUNT(*) as total 
            FROM bookings b 
            JOIN farmhouses f ON b.farmhouse_id = f.id 
            WHERE f.admin_id = ? AND b.status = 'Confirmed'
        ");
        $stmt->bind_param("i", $admin_id);
        $stmt->execute();
        $stats['confirmed_bookings'] = $stmt->get_result()->fetch_assoc()['total'];
        
        // Total revenue
        $stmt = $this->conn->prepare("
            SELECT SUM(b.total_amount) as total 
            FROM bookings b 
            JOIN farmhouses f ON b.farmhouse_id = f.id 
            WHERE f.admin_id = ? AND b.status = 'Confirmed'
        ");
        $stmt->bind_param("i", $admin_id);
        $stmt->execute();
        $result = $stmt->get_result()->fetch_assoc();
        $stats['total_revenue'] = $result['total'] ? $result['total'] : 0;
        
        return $stats;
    }
    
    public function getRecentBookings($admin_id, $limit = 5) {
        $stmt = $this->conn->prepare("
            SELECT b.*, f.name as farmhouse_name, u.name as user_name
            FROM bookings b 
            JOIN farmhouses f ON b.farmhouse_id = f.id 
            JOIN users u ON b.user_id = u.id
            WHERE f.admin_id = ? 
            ORDER BY b.created_at DESC 
            LIMIT ?
        ");
        $stmt->bind_param("ii", $admin_id, $limit);
        $stmt->execute();
        return $stmt->get_result()->fetch_all(MYSQLI_ASSOC);
    }
    
    public function getFarmhouses($admin_id) {
        $stmt = $this->conn->prepare("
            SELECT * FROM farmhouses 
            WHERE admin_id = ? 
            ORDER BY created_at DESC
        ");
        $stmt->bind_param("i", $admin_id);
        $stmt->execute();
        return $stmt->get_result()->fetch_all(MYSQLI_ASSOC);
    }
    
    public function getBookings($admin_id, $status = null) {
        $sql = "
            SELECT b.*, f.name as farmhouse_name, u.name as user_name, u.email as user_email
            FROM bookings b 
            JOIN farmhouses f ON b.farmhouse_id = f.id 
            JOIN users u ON b.user_id = u.id
            WHERE f.admin_id = ?
        ";
        
        if ($status) {
            $sql .= " AND b.status = ?";
            $stmt = $this->conn->prepare($sql);
            $stmt->bind_param("is", $admin_id, $status);
        } else {
            $stmt = $this->conn->prepare($sql);
            $stmt->bind_param("i", $admin_id);
        }
        
        $stmt->execute();
        return $stmt->get_result()->fetch_all(MYSQLI_ASSOC);
    }
    
    public function updateBookingStatus($booking_id, $status) {
        $stmt = $this->conn->prepare("UPDATE bookings SET status = ? WHERE id = ?");
        $stmt->bind_param("si", $status, $booking_id);
        return $stmt->execute();
    }
    
    public function addFarmhouse($admin_id, $data) {
        $stmt = $this->conn->prepare("
            INSERT INTO farmhouses (admin_id, name, description, location, price_per_night, capacity, amenities, images) 
            VALUES (?, ?, ?, ?, ?, ?, ?, ?)
        ");
        $stmt->bind_param("isssdsss", 
            $admin_id, 
            $data['name'], 
            $data['description'], 
            $data['location'], 
            $data['price_per_night'], 
            $data['capacity'], 
            $data['amenities'], 
            $data['images']
        );
        return $stmt->execute();
    }
    
    public function updateFarmhouse($farmhouse_id, $admin_id, $data) {
        $stmt = $this->conn->prepare("
            UPDATE farmhouses 
            SET name = ?, description = ?, location = ?, price_per_night = ?, 
                capacity = ?, amenities = ?, images = ?
            WHERE id = ? AND admin_id = ?
        ");
        $stmt->bind_param("sssdsssii", 
            $data['name'], 
            $data['description'], 
            $data['location'], 
            $data['price_per_night'], 
            $data['capacity'], 
            $data['amenities'], 
            $data['images'],
            $farmhouse_id,
            $admin_id
        );
        return $stmt->execute();
    }
    
    public function deleteFarmhouse($farmhouse_id, $admin_id) {
        $stmt = $this->conn->prepare("DELETE FROM farmhouses WHERE id = ? AND admin_id = ?");
        $stmt->bind_param("ii", $farmhouse_id, $admin_id);
        return $stmt->execute();
    }
    
    public function getFarmhouseById($farmhouse_id, $admin_id) {
        $stmt = $this->conn->prepare("SELECT * FROM farmhouses WHERE id = ? AND admin_id = ?");
        $stmt->bind_param("ii", $farmhouse_id, $admin_id);
        $stmt->execute();
        return $stmt->get_result()->fetch_assoc();
    }
}
?>
