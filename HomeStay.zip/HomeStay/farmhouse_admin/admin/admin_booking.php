<?php
session_start();
include '../config/config.php';

$admin = new Admin();
$conn = $admin->getConn();

// Make sure admin is logged in
if (!isset($_SESSION['admin_id'])) {
  echo "<script>alert('Please log in as admin first'); window.location='admin_login.php';</script>";
  exit;
}

$admin_id = $_SESSION['admin_id']; // Logged-in admin's ID

// Fetch bookings only for this admin's farmhouses
$sql = "SELECT b.*, f.name AS farmhouse_name 
        FROM book b
        JOIN farmhouses f ON b.farmhouse_id = f.id 
        WHERE f.admin_id = ? 
        ORDER BY b.created_at DESC";


$stmt = $conn->prepare($sql);
$stmt->bind_param("i", $admin_id);
$stmt->execute();
$result = $stmt->get_result();
?>

<!DOCTYPE html>
<html>
<head>
  <meta charset="UTF-8">
  <title>Admin Booking Details - FindMyHomeStay</title>
  <style>
    body { font-family: Arial, sans-serif; background: #f4f6f8; }
    h2 { text-align: center; margin: 2rem 0 1rem; color: #2e7d32; }
    table {
      width: 95%;
      margin: auto;
      border-collapse: collapse;
      background: white;
      box-shadow: 0 0 10px rgba(0,0,0,0.1);
    }
    th, td {
      padding: 12px 16px;
      border: 1px solid #ddd;
      text-align: center;
    }
    th {
      background-color: #2e7d32;
      color: white;
    }
    tr:nth-child(even) { background-color: #f2f2f2; }
    tr:hover { background-color: #e8f5e9; }
    button {
      padding: 6px 12px;
      margin: 0 4px;
      background-color: #4caf50;
      color: white;
      border: none;
      border-radius: 4px;
      cursor: pointer;
    }
    button:hover { background-color: #388e3c; }
  </style>
</head>
<body>

<h2>Admin Booking Details</h2>

<table>
  <thead>
    <tr>
      <th>Farmhouse</th>
      <th>Full Name</th>
      <th>Email</th>
      <th>Phone Number</th>
      <th>Number of Guests</th>
      <th>Check-in Date</th>
      <th>Check-out Date</th>
      <th>Status</th>
      <th>Action</th>
    </tr>
  </thead>
  <tbody>
    <?php
    if ($result->num_rows > 0) {
      while ($row = $result->fetch_assoc()) {
        echo "<tr>
          <td>{$row['farmhouse_name']}</td>
          <td>{$row['full_name']}</td>
          <td>{$row['email']}</td>
          <td>{$row['phone']}</td>
          <td>{$row['guests']}</td>
          <td>{$row['checkin_date']}</td>
          <td>{$row['checkout_date']}</td>
          <td style='color:" . 
              ($row['status'] == 'Accepted' ? 'green' : 
              ($row['status'] == 'Rejected' ? 'red' : 'orange')) . 
            "'>{$row['status']}</td>
          <td>";

        if ($row['status'] == 'Pending') {
          echo "<form method='POST' action='update_booking_status.php'>
                  <input type='hidden' name='booking_id' value='{$row['id']}'>
                  <button name='status' value='Accepted'>Accept</button>
                  <button name='status' value='Rejected'>Reject</button>
                </form>";
        } else {
          echo $row['status'];
        }

        echo "</td></tr>";
      }
    } else {
      echo "<tr><td colspan='9'>No bookings available for your farmhouses.</td></tr>";
    }
    ?>
  </tbody>
</table>

</body>
</html>
