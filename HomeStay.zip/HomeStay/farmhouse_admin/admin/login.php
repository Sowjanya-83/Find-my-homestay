<?php
session_start(); // You missed this

include '../config/config.php';
$admin = new Admin();
$conn = $admin->getConn();

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $email = $_POST['email'];
    $password = $_POST['password'];

    $stmt = $conn->prepare("SELECT id, password FROM admins WHERE email = ?");
    $stmt->bind_param("s", $email);
    $stmt->execute();
    $stmt->bind_result($id, $hashed);

    if ($stmt->fetch() && password_verify($password, $hashed)) {
        $_SESSION['admin_id'] = $id;
        header("Location: admin_dashboard.php"); // ✅ Redirect here
        exit();
    } else {
        echo "<script>alert('Invalid credentials'); window.history.back();</script>";
    }
}
?>
