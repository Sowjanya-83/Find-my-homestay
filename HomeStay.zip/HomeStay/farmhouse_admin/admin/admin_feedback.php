<?php
session_start();
include '../config/config.php';

$admin = new Admin();
$conn = $admin->getConn();

$admin_id = $_SESSION['admin_id'] ?? 0; // assume admin is logged in

if (!$admin_id) {
    echo "<script>alert('Admin not logged in'); window.location='login.php';</script>";
    exit;
}

$stmt = $conn->prepare("
    SELECT f.full_name, f.email, f.message, fh.name AS farmhouse_name 
    FROM feedback f
    JOIN farmhouses fh ON f.farmhouse_id = fh.id
    WHERE f.admin_id = ?
");

$stmt->bind_param("i", $admin_id);
$stmt->execute();
$result = $stmt->get_result();
?>

<!DOCTYPE html>
<html>
<head>
  <title>Admin Feedback</title>
  <style>
    body { font-family: Arial, sans-serif; background: #f4f6f8; padding: 20px; }
    h2 { color: #2e7d32; text-align: center; }
    table { width: 100%; border-collapse: collapse; background: #fff; margin-top: 20px; }
    th, td { padding: 12px; border: 1px solid #ccc; text-align: left; }
    th { background: #2e7d32; color: #fff; }
    tr:nth-child(even) { background: #f9f9f9; }
    .sidebar {
      width: 260px;
      background: linear-gradient(180deg, #006400, #32CD32);
      color: #fff;
      height: 100vh;
      position: fixed;
      padding: 30px 20px;
      display: flex;
      flex-direction: column;
      align-items: center;
      border-right: 2px solid rgba(255, 255, 255, 0.2);
      box-shadow: 4px 0 20px rgba(0,0,0,0.1);
    }

    .sidebar h2 {
      font-size: 26px;
      font-weight: bold;
      margin-bottom: 6px;
      color: white;
    }

    .sidebar h4 {
      font-size: 15px;
      font-weight: normal;
      color:white;
      margin-bottom: 30px;
    }

    .sidebar a {
      width: 100%;
      padding: 12px 20px;
      margin: 8px 0;
      color: #fff;
      background: rgba(255, 255, 255, 0.1);
      border-radius: 10px;
      text-decoration: none;
      font-weight: 500;
      display: flex;
      align-items: center;
      gap: 12px;
      transition: all 0.3s ease;
    }

    .sidebar a:hover, .sidebar a.active {
      background: rgba(255, 255, 255, 0.3);
      transform: scale(1.05);
    }

    .sidebar a i {
      font-size: 18px;
    }

    .main-content {
      margin-left: 260px;
      padding: 40px;
      width: 100%;
    }

    .section {
      display: none;
    }

    .section.active {
      display: block;
    }

    h2 {
      font-size: 28px;
      margin-bottom: 30px;
      color: #2e5939;
      text-align: center;
    }

    .dashboard-cards {
      display: flex;
      gap: 30px;
      flex-wrap: wrap;
      justify-content: center;
    }

    .card {
      background: linear-gradient(135deg, #ffffff, #e8f5e9);
      border-radius: 16px;
      box-shadow: 0 6px 18px rgba(0, 128, 0, 0.1);
      padding: 30px;
      flex: 1;
      min-width: 250px;
      max-width: 300px;
      transition: transform 0.3s ease;
      text-align: center;
    }

    .card:hover {
      transform: scale(1.05);
    }

    .card i {
      font-size: 32px;
      margin-bottom: 15px;
      color: #228B22;
    }

    .card h3 {
      font-size: 22px;
      margin-bottom: 10px;
      color: #3b553b;
    }

    .card span {
      font-size: 36px;
      font-weight: bold;
      color: #1b381b;
    }

    /* Form Section Styling */
    #homestay form {
      background: white;
      padding: 30px;
      border-radius: 12px;
      box-shadow: 0 6px 20px rgba(0, 128, 0, 0.1);
      max-width: 600px;
      margin: 0 auto;
      display: flex;
      flex-direction: column;
    }

    form input, form textarea, form button {
      width: 100%;
      padding: 12px;
      margin-bottom: 20px;
      border: 1px solid #ccc;
      border-radius: 8px;
      font-size: 16px;
    }

    form button {
      background: #228B22;
      color: white;
      font-weight: bold;
      border: none;
      cursor: pointer;
      transition: 0.3s;
    }

    form button:hover {
      background: #1a6f1a;
    }

    .footer {
      margin-top: 40px;
      text-align: center;
      color: #777;
      font-size: 14px;
    }
  </style>
</head>
<body>
    <div class="sidebar">
     <h2>FindMyHomeStay</h2>
    <h4>Admin panel</h4>
    <a href="#" onclick="showSection('dashboard'); setActive(this)" class="active"><i class="fas fa-chart-line"></i> Dashboard</a>
    <a href="#" onclick="showSection('homestay'); setActive(this)"><i class="fas fa-plus-circle"></i> Add Homestay</a>
    <a href="admin_feedback.php" onclick="showSection('feedback'); setActive(this)"><i class="fas fa-comments"></i> Feedback</a>
    <a href="admin_booking.php" onclick="showSection('status'); setActive(this)"><i class="fas fa-clipboard-check"></i> Booking Status</a>
    <a href="login.html"><i class="fas fa-sign-out-alt"></i> Logout</a>
  </div>


<h2>Feedback Received for Your Farmhouses</h2>

<table>
  <tr>
    <th>Farmhouse</th>
    <th>Name</th>
    <th>Email</th>
    <th>Message</th>
  
  </tr>

  <?php if ($result->num_rows > 0): ?>
    <?php while ($row = $result->fetch_assoc()): ?>
      <tr>
        <td><?= htmlspecialchars($row['farmhouse_name']) ?></td>
        <td><?= htmlspecialchars($row['full_name']) ?></td>
        <td><?= htmlspecialchars($row['email']) ?></td>
        <td><?= htmlspecialchars($row['message']) ?></td>
        
      </tr>
    <?php endwhile; ?>
  <?php else: ?>
    <tr><td colspan="5">No feedback received yet.</td></tr>
  <?php endif; ?>

</table>

</body>
</html>
