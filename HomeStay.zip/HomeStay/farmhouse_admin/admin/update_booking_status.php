<?php
include '../config/config.php';

$admin = new Admin();
$conn = $admin->getConn();

$booking_id = $_POST['booking_id'];
$status = $_POST['status'];

$conn->query("UPDATE book SET status = '$status' WHERE id = $booking_id");

// Redirect to admin_dashboard.php instead of admin_booking.php
header("Location: admin_dashboard.php#status");
exit;
