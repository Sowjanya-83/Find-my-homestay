<?php
include '../config/config.php'; // ✅ Corrected path from admin/ to config/

$admin = new Admin();
$conn = $admin->getConn();

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $name = $_POST['name'];
    $email = $_POST['email'];
    $password = password_hash($_POST['password'], PASSWORD_DEFAULT);  // use plain $_POST['password'] if not hashing

    $check = $conn->prepare("SELECT id FROM admins WHERE email=?");
    $check->bind_param("s", $email);
    $check->execute();
    $check->store_result();
    if ($check->num_rows > 0) {
        echo "<script>alert('Email already exists'); window.history.back();</script>";
        exit;
    }

    $stmt = $conn->prepare("INSERT INTO admins (name,email,password) VALUES (?,?,?)");
    $stmt->bind_param("sss", $name, $email, $password);
    if ($stmt->execute()) {
        echo "<script>alert('Registration successful'); window.location='login.html';</script>";
    } else {
        echo "<script>alert('Failed to register'); window.history.back();</script>";
    }
}
?>
