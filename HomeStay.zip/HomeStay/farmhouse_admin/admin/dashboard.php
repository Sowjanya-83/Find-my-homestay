<?php
include '../config/config.php';
if (!isset($_SESSION['admin_id'])) { header("Location: login.php"); exit; }
$admin = new Admin();
$conn = $admin->getConn();
$id = $_SESSION['admin_id'];

$total_farmhouses = $conn->query("SELECT COUNT(*) FROM farmhouses WHERE admin_id=$id")->fetch_row()[0];
$total_bookings = $conn->query("SELECT COUNT(*) FROM bookings b JOIN farmhouses f ON b.farmhouse_id=f.id WHERE f.admin_id=$id")->fetch_row()[0];
$pending = $conn->query("SELECT COUNT(*) FROM bookings b JOIN farmhouses f ON b.farmhouse_id=f.id WHERE f.admin_id=$id AND b.status='Pending'")->fetch_row()[0];
?>
<!DOCTYPE html>
<html>
<head><title>Dashboard</title></head>
<body>
<h2>Welcome Admin</h2>
<p>Total Farmhouses: <?= $total_farmhouses ?></p>
<p>Total Bookings: <?= $total_bookings ?></p>
<p>Pending Bookings: <?= $pending ?></p>
<a href="add_farmhouse.php">Add Farmhouse</a> |
<a href="view_bookings.php">View Bookings</a> |
<a href="logout.php">Logout</a>
</body>
</html>
