<?php
session_start();
include '../config/config.php'; // Adjust if needed

$admin = new Admin();
$conn = $admin->getConn();

$admin_id = $_SESSION['admin_id'] ?? 0;

if (!$admin_id) {
    echo "<script>alert('Admin not logged in'); window.location='login.php';</script>";
    exit;
}

// Handle status update if POST request received
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['booking_id'], $_POST['status'])) {
    $booking_id = intval($_POST['booking_id']);
    $status = in_array($_POST['status'], ['Accepted', 'Rejected']) ? $_POST['status'] : 'Pending';
    $updateStmt = $conn->prepare("UPDATE book SET status = ? WHERE id = ?");
    $updateStmt->bind_param("si", $status, $booking_id);
    $updateStmt->execute();
    $updateStmt->close();
    // Refresh page after update
    header("Location: admin_dashboard.php");
    exit;
}

$homestayCountStmt = $conn->prepare("SELECT COUNT(*) FROM farmhouses WHERE admin_id = ?");
$homestayCountStmt->bind_param("i", $admin_id);
$homestayCountStmt->execute();
$homestayCountStmt->bind_result($totalHomestays);
$homestayCountStmt->fetch();
$homestayCountStmt->close();

$bookingCountStmt = $conn->prepare("SELECT COUNT(*) FROM book b JOIN farmhouses f ON b.farmhouse_id = f.id WHERE f.admin_id = ?");
$bookingCountStmt->bind_param("i", $admin_id);
$bookingCountStmt->execute();
$bookingCountStmt->bind_result($totalBookings);
$bookingCountStmt->fetch();
$bookingCountStmt->close();

$feedbackCountStmt = $conn->prepare("SELECT COUNT(*) FROM feedback WHERE admin_id = ?");
$feedbackCountStmt->bind_param("i", $admin_id);
$feedbackCountStmt->execute();
$feedbackCountStmt->bind_result($totalFeedbacks);
$feedbackCountStmt->fetch();
$feedbackCountStmt->close();

$stmt = $conn->prepare("
    SELECT f.full_name, f.email, f.message, fh.name AS farmhouse_name 
    FROM feedback f
    JOIN farmhouses fh ON f.farmhouse_id = fh.id
    WHERE f.admin_id = ?
");
$stmt->bind_param("i", $admin_id);
$stmt->execute();
$result = $stmt->get_result();

$bookingStmt = $conn->prepare("
    SELECT b.id, b.full_name, b.email, b.phone, b.guests, b.checkin_date, b.checkout_date, b.status, fh.name AS farmhouse_name 
    FROM book b
    JOIN farmhouses fh ON b.farmhouse_id = fh.id
    WHERE fh.admin_id = ?
");
$bookingStmt->bind_param("i", $admin_id);
$bookingStmt->execute();
$bookingResult = $bookingStmt->get_result();
?>

<!-- No change needed in HTML section -->



<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>Admin Dashboard - FindMyHomeStay</title>
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@400;600&display=swap" rel="stylesheet">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css"/>
  <style>
    * { margin: 0; padding: 0; box-sizing: border-box; }
    body { font-family: 'Poppins', sans-serif; background: #f1f9f4; display: flex; }
    .sidebar {
      width: 260px;
      background: linear-gradient(180deg, #006400, #32CD32);
      color: #fff;
      height: 100vh;
      position: fixed;
      padding: 30px 20px;
      display: flex;
      flex-direction: column;
      align-items: center;
      border-right: 2px solid rgba(255, 255, 255, 0.2);
      box-shadow: 4px 0 20px rgba(0,0,0,0.1);
    }
    .sidebar h2 { font-size: 26px; font-weight: bold; margin-bottom: 6px; color: white; }
    .sidebar h4 { font-size: 15px; color: white; margin-bottom: 30px; }
    .sidebar a {
      width: 100%;
      padding: 12px 20px;
      margin: 8px 0;
      color: #fff;
      background: rgba(255, 255, 255, 0.1);
      border-radius: 10px;
      text-decoration: none;
      font-weight: 500;
      display: flex;
      align-items: center;
      gap: 12px;
      transition: all 0.3s ease;
    }
    .sidebar a:hover, .sidebar a.active {
      background: rgba(255, 255, 255, 0.3);
      transform: scale(1.05);
    }
    .sidebar a i { font-size: 18px; }
    .main-content {
      margin-left: 260px;
      padding: 40px;
      width: 100%;
    }
    .section { display: none; }
    .section.active { display: block; }
    h2 { font-size: 28px; margin-bottom: 30px; color: #2e5939; text-align: center; }

    .dashboard-cards {
      display: flex;
      gap: 30px;
      flex-wrap: wrap;
      justify-content: center;
    }
    .card {
      background: linear-gradient(135deg, #ffffff, #e8f5e9);
      border-radius: 16px;
      box-shadow: 0 6px 18px rgba(0, 128, 0, 0.1);
      padding: 30px;
      flex: 1;
      min-width: 250px;
      max-width: 300px;
      transition: transform 0.3s ease;
      text-align: center;
    }
    .card:hover { transform: scale(1.05); }
    .card i { font-size: 32px; margin-bottom: 15px; color: #228B22; }
    .card h3 { font-size: 22px; margin-bottom: 10px; color: #3b553b; }
    .card span { font-size: 36px; font-weight: bold; color: #1b381b; }

    #homestay form {
      background: white;
      padding: 30px;
      border-radius: 12px;
      box-shadow: 0 6px 20px rgba(0, 128, 0, 0.1);
      max-width: 600px;
      margin: 0 auto;
      display: flex;
      flex-direction: column;
    }
    form input, form textarea, form button {
      width: 100%;
      padding: 12px;
      margin-bottom: 20px;
      border: 1px solid #ccc;
      border-radius: 8px;
      font-size: 16px;
    }
    form button {
      background: #228B22;
      color: white;
      font-weight: bold;
      border: none;
      cursor: pointer;
      transition: 0.3s;
    }
    form button:hover { background: #1a6f1a; }

    table {
      width: 100%;
      border-collapse: collapse;
      background: #fff;
      margin-top: 20px;
    }
    th, td {
      padding: 12px;
      border: 1px solid #ccc;
      text-align: left;
    }
    th { background: #2e7d32; color: #fff; }
    tr:nth-child(even) { background: #f9f9f9; }

    .footer {
      margin-top: 40px;
      text-align: center;
      color: #777;
      font-size: 14px;
    }
  </style>
</head>
<body>
  <div class="sidebar">
    <h2>FindMyHomeStay</h2>
    <h4>Admin panel</h4>
    <a href="#" onclick="showSection('dashboard'); setActive(this)" class="active"><i class="fas fa-chart-line"></i> Dashboard</a>
    <a href="#" onclick="showSection('homestay'); setActive(this)"><i class="fas fa-plus-circle"></i> Add Homestay</a>
    <a href="#" onclick="showSection('feedback'); setActive(this)"><i class="fas fa-comments"></i> Feedback</a>
    <a href="#" onclick="showSection('status'); setActive(this)"><i class="fas fa-clipboard-check"></i> Booking Status</a>
    <a href="login.html"><i class="fas fa-sign-out-alt"></i> Logout</a>
  </div>

  <div class="main-content">
    <div id="dashboard" class="section active">
      <h2>Dashboard Overview</h2>
      <div class="dashboard-cards">
        <div class="card">
          <i class="fas fa-home"></i>
          <h3>Total Homestays</h3>
         <span><?= $totalHomestays ?></span>
        </div>
        <div class="card">
          <i class="fas fa-calendar-check"></i>
          <h3>Total Bookings</h3>
       <span><?= $totalBookings ?></span>
        </div>
        <div class="card">
          <i class="fas fa-comment-dots"></i>
          <h3>Feedbacks</h3>
           <span><?= $totalFeedbacks ?></span>
        </div>
      </div>
    </div>

    <div id="homestay" class="section">
      <h2>Add Homestay</h2>
      <form action="controller/add_farmhouse.php" method="POST" enctype="multipart/form-data">
        <input type="text" name="name" placeholder="Homestay Name" required />
        <input type="text" name="location" placeholder="Location" required />
        <input type="number" name="price" placeholder="Price per night (INR)" step="0.01" required />
        <textarea name="description" placeholder="Description" rows="4" required></textarea>
        <label>Main Image</label>
        <input type="file" name="image" accept="image/*" required />
        <label>Gallery Images</label>
        <input type="file" name="image1" accept="image/*" required />
        <input type="file" name="image2" accept="image/*" required />
        <input type="file" name="image3" accept="image/*" required />
        <input type="file" name="image4" accept="image/*" required />
        <button type="submit">Submit Homestay</button>
      </form>
    </div>

    <div id="feedback" class="section">
      <h2>Feedback Received for Your Farmhouses</h2>
      <table>
        <tr>
          <th>Farmhouse</th>
          <th>Name</th>
          <th>Email</th>
          <th>Message</th>
        </tr>
        <?php if ($result->num_rows > 0): ?>
          <?php while ($row = $result->fetch_assoc()): ?>
            <tr>
              <td><?= htmlspecialchars($row['farmhouse_name']) ?></td>
              <td><?= htmlspecialchars($row['full_name']) ?></td>
              <td><?= htmlspecialchars($row['email']) ?></td>
              <td><?= htmlspecialchars($row['message']) ?></td>
            </tr>
          <?php endwhile; ?>
        <?php else: ?>
          <tr><td colspan="4">No feedback received yet.</td></tr>
        <?php endif; ?>
      </table>
    </div>

     <div id="status" class="section">
      <h2>Booking Status</h2>
      <table>
        <tr>
          <th>Farmhouse</th>
          <th>Name</th>
          <th>Email</th>
          <th>Phone</th>
          <th>Guests</th>
          <th>Check-in</th>
          <th>Check-out</th>
          <th>Status</th>
          <th>Action</th>
        </tr>
        <?php if ($bookingResult->num_rows > 0): while ($row = $bookingResult->fetch_assoc()): ?>
          <tr>
            <td><?= htmlspecialchars($row['farmhouse_name']) ?></td>
            <td><?= htmlspecialchars($row['full_name']) ?></td>
            <td><?= htmlspecialchars($row['email']) ?></td>
            <td><?= htmlspecialchars($row['phone']) ?></td>
            <td><?= htmlspecialchars($row['guests']) ?></td>
            <td><?= htmlspecialchars($row['checkin_date']) ?></td>
            <td><?= htmlspecialchars($row['checkout_date']) ?></td>
            <td style="color:<?= $row['status'] === 'Accepted' ? 'green' : ($row['status'] === 'Rejected' ? 'red' : 'orange') ?>">
              <?= htmlspecialchars($row['status']) ?>
            </td>
            <td>
              <?php if ($row['status'] === 'Pending'): ?>
                <form method="POST" action="update_booking_status.php" style="display:inline-block;">
                  <input type="hidden" name="booking_id" value="<?= $row['id'] ?>">
                  <button type="submit" name="status" value="Accepted" class="btn-accept">Accept</button>
                </form>
                <form method="POST" action="update_booking_status.php" style="display:inline-block;">
                  <input type="hidden" name="booking_id" value="<?= $row['id'] ?>">
                  <button type="submit" name="status" value="Rejected" class="btn-reject">Reject</button>
                </form>
              <?php else: ?>
                <?= htmlspecialchars($row['status']) ?>
              <?php endif; ?>
            </td>
          </tr>
        <?php endwhile; else: ?>
          <tr><td colspan="9">No bookings found.</td></tr>
        <?php endif; ?>
      </table>
    </div>

  <script>
    function showSection(id) {
      document.querySelectorAll('.section').forEach(section => section.classList.remove('active'));
      document.getElementById(id).classList.add('active');
    }
    function setActive(link) {
      document.querySelectorAll('.sidebar a').forEach(a => a.classList.remove('active'));
      link.classList.add('active');
    }
  </script>
</body>
</html>
