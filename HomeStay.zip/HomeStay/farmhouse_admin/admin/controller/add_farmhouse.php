<?php
session_start();
include '../../config/config.php';

$admin = new Admin();
$conn = $admin->getConn();

if (!isset($_SESSION['admin_id'])) {
    header("Location: ../login.html");
    exit();
}

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $admin_id = $_SESSION['admin_id'];
    $name = $_POST['name'];
    $location = $_POST['location'];
    $price = $_POST['price'];
    $description = $_POST['description'];

    $upload_dir = "../uploads/";
    if (!is_dir($upload_dir)) {
        mkdir($upload_dir, 0777, true);
    }

    // Upload main image (stored in 'image' column)
    $main_image = '';
    if (isset($_FILES['image']) && $_FILES['image']['error'] === 0) {
        $main_image = basename($_FILES['image']['name']);
        $target_file = $upload_dir . $main_image;
        move_uploaded_file($_FILES['image']['tmp_name'], $target_file);
    }

    // Upload image1 to image4 (gallery)
    $image_names = [];
    for ($i = 1; $i <= 4; $i++) {
        $input_name = 'image' . $i;
        if (isset($_FILES[$input_name]) && $_FILES[$input_name]['error'] === 0) {
            $image_name = basename($_FILES[$input_name]['name']);
            $target_file = $upload_dir . $image_name;
            move_uploaded_file($_FILES[$input_name]['tmp_name'], $target_file);
            $image_names[$i] = $image_name;
        } else {
            $image_names[$i] = '';
        }
    }

    // INSERT into farmhouses table
    $stmt = $conn->prepare("INSERT INTO farmhouses (admin_id, name, location, price, image, description, image1, image2, image3, image4) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)");
    $stmt->bind_param("issdssssss", $admin_id, $name, $location, $price, $main_image, $description, $image_names[1], $image_names[2], $image_names[3], $image_names[4]);

    if ($stmt->execute()) {
        echo "<script>alert('Homestay added successfully!'); window.location='../home.html';</script>";
    } else {
        echo "<script>alert('Error adding homestay.'); window.history.back();</script>";
    }
}

?>

<?php
// Include database connection
include 'farmhouse_admin/config/config.php';
$admin = new Admin();
$conn = $admin->getConn();

// Get farmhouse ID from URL
$id = isset($_GET['id']) ? intval($_GET['id']) : 0;

// Fetch farmhouse details from DB
$sql = "SELECT * FROM farmhouses WHERE id = $id";
$result = $conn->query($sql);

if ($result->num_rows > 0) {
  $row = $result->fetch_assoc();
  $name = htmlspecialchars($row['name']);
  $location = htmlspecialchars($row['location']);
  $description = htmlspecialchars($row['description']);
  $image=htmlspecialchars($row['image']);

  $images = [
    htmlspecialchars($row['image1']),
    htmlspecialchars($row['image2']),
    htmlspecialchars($row['image3']),
    htmlspecialchars($row['image4'])
  ];
} else {
  echo "<h2 style='text-align:center;'>Homestay not found.</h2>";
  exit();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0"/>
  <title><?php echo $name; ?> | <?php echo $location; ?></title>
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
  <!-- Place your full CSS here -->
</head>
<body>
  <header>
    <div>
      <h1><?php echo $name; ?></h1>
      <p>Your nature getaway in <?php echo $location; ?></p>
    </div>
    <nav>
      <a href="udupi.html">Home</a>
      <a href="status.html">Status</a>
    </nav>
  </header>

  <section class="gallery-section">
    <h2>Our Homestay Views</h2>
    <div class="gallery">
      <?php foreach ($images as $img) {
        if (!empty($img)) {
          echo '<div class="gallery-item"><img src="farmhouse_admin/admin/uploads/' . $img . '" alt="Homestay Image"></div>';
        }
      } ?>
    </div>
  </section>

  <section class="about">
    <h2>About the Homestay</h2>
    <p><?php echo nl2br($description); ?></p>
  </section>

  <!-- Static Facilities Section -->
  <section class="facilities-section">
    <div class="section-title">
      <h2 style="text-align:center;">Our Facilities</h2>
    </div>
    <div class="facilities-grid">
      <div class="facility-card"><div class="facility-icon"><i class="fas fa-wifi"></i></div><h3>Free Wi-Fi</h3><p>High-speed internet throughout the property</p></div>
      <div class="facility-card"><div class="facility-icon"><i class="fas fa-utensils"></i></div><h3>Complimentary Breakfast</h3><p>Delicious local flavors to start your day</p></div>
      <div class="facility-card"><div class="facility-icon"><i class="fas fa-fire"></i></div><h3>Campfire & BBQ</h3><p>Evenings made magical on request</p></div>
      <div class="facility-card"><div class="facility-icon"><i class="fas fa-tree"></i></div><h3>Plantation Walks</h3><p>Explore the estate with guided nature tours</p></div>
      <div class="facility-card"><div class="facility-icon"><i class="fas fa-bolt"></i></div><h3>Power Backup</h3><p>24/7 electricity for uninterrupted comfort</p></div>
      <div class="facility-card"><div class="facility-icon"><i class="fas fa-broom"></i></div><h3>Clean Rooms</h3><p>Hygienic and well-maintained accommodation</p></div>
      <div class="facility-card"><div class="facility-icon"><i class="fas fa-water"></i></div><h3>Hot Water</h3><p>Always available in all bathrooms</p></div>
      <div class="facility-card"><div class="facility-icon"><i class="fas fa-parking"></i></div><h3>Parking</h3><p>Secure parking space for all guests</p></div>
    </div>
  </section>

  <section class="cta-section" id="book">
    <h2>Ready for Your Perfect Getaway?</h2>
    <p>Book your stay now and experience the magic of <?php echo $location; ?> with our warm hospitality.</p>
    <a href="book.html" class="btn">Book Now <i class="fas fa-calendar-check"></i></a>
  </section>

  <footer>
    <p>&copy; 2025 Find My HomeStay. All rights reserved.</p>
  </footer>
</body>
</html>
