<?php
session_start();

$farmhouse_id = $_GET['farmhouse_id'] ?? 0;

?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <title>Feedback - FindMyHomeStay</title>
  <style>
    /* ... same CSS as before ... */
    * { margin: 0; padding: 0; box-sizing: border-box; }
    body { font-family: Arial, sans-serif; background: #f4f6f8; }
    header { background-color: #2e7d32; color: white; padding: 1rem 2rem; display: flex; justify-content: space-between; align-items: center; }
    .logo { font-size: 1.5rem; font-weight: bold; }
    nav a { color: white; margin-left: 20px; text-decoration: none; font-weight: bold; transition: color 0.3s; }
    nav a:hover { color: #c8e6c9; }
    .feedback-container { max-width: 600px; margin: 50px auto; background: white; padding: 30px; border-radius: 10px; box-shadow: 0 0 10px rgba(0,0,0,0.1); }
    h2 { text-align: center; margin-bottom: 20px; color: #2e7d32; }
    label { display: block; margin-bottom: 8px; font-weight: bold; }
    input[type="text"], input[type="email"], textarea {
      width: 100%; padding: 10px; margin-bottom: 20px;
      border: 1px solid #ccc; border-radius: 5px; font-size: 1rem;
    }
    textarea { resize: vertical; min-height: 100px; }
    button {
      background-color: #4caf50; color: white; padding: 10px 20px;
      border: none; border-radius: 5px; font-size: 1rem;
      cursor: pointer; display: block; margin: auto;
    }
    button:hover { background-color: #388e3c; }
    footer {
      text-align: center; padding: 1rem; margin-top: 2rem;
      background-color: #fff; color: #666; font-size: 0.9rem;
    }
    @media (max-width: 768px) {
      header { flex-direction: column; align-items: flex-start; }
      nav { margin-top: 0.5rem; }
      nav a { display: inline-block; margin-left: 0; margin-right: 15px; }
    }
  </style>
</head>
<body>

<header>
  <div class="logo">FindMyHomeStay</div>
  <nav>
    <a href="homee.html">Home</a>
    <a href="status.php">Booking Status</a>
  </nav>
</header>

<div class="feedback-container">
  <h2>We Value Your Feedback</h2>
  <form action="submit_feedback.php" method="post">
  <input type="hidden" name="farmhouse_id" value="<?= htmlspecialchars($farmhouse_id) ?>">

  <label for="name">Full Name:</label>
  <input type="text" id="name" name="full_name" required>

  <label for="email">Email:</label>
  <input type="email" id="email" name="email">

  <label for="message">Your Feedback:</label>
  <textarea id="message" name="message" required></textarea>

  <button type="submit">Submit Feedback</button>
</form>


</div>

<footer>
  &copy; 2025 FindMyHomeStay. All rights reserved.
</footer>

</body>
</html>
