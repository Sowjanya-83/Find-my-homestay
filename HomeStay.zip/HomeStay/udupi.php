<?php
// Include the database configuration from farmhouse/config/config.php
include 'farmhouse_admin/config/config.php'; // ✅ Corrected path

// Create connection using Admin class
$admin = new Admin();
$conn = $admin->getConn();

// Fetch only farmhouses with location = 'Udupi'
$sql = "SELECT * FROM farmhouses WHERE location = 'Udupi'";
$result = $conn->query($sql);
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1" />
  <title>Find My HomeStay in Udupi</title>
  <style>
    * {
      margin: 0;
      padding: 0;
      box-sizing: border-box;
    }

    body {
      font-family: Arial, sans-serif;
      background-color: #f1f8e9;
      color: #333;
    }

    header {
      background: linear-gradient(to right, #1b5e20, #4caf50);
      padding: 15px 30px;
      display: flex;
      justify-content: space-between;
      align-items: center;
      box-shadow: 0 2px 6px rgba(0, 0, 0, 0.25);
      position: sticky;
      top: 0;
      z-index: 10;
    }

    .logo {
      font-size: 1.8rem;
      font-weight: bold;
      color: #fff;
    }

    nav {
      display: flex;
      gap: 25px;
    }

    nav a {
      color: #fff;
      text-decoration: none;
      font-size: 1rem;
      font-weight: 500;
      transition: color 0.3s ease;
    }

    nav a:hover {
      color: yellow;
    }

    h1 {
      text-align: center;
      color: green;
      font-size: 2.5rem;
      padding: 30px 0 10px;
      font-family: Georgia, 'Times New Roman', Times, serif;
    }

    .homestays {
      display: flex;
      flex-wrap: wrap;
      justify-content: center;
      gap: 30px;
      padding: 30px 50px;
    }

    .card {
      width: 300px;
      border-radius: 15px;
      overflow: hidden;
      background-color: #fff;
      box-shadow: 0 8px 18px rgba(0, 0, 0, 0.15);
      transition: transform 0.3s ease, box-shadow 0.3s ease;
    }

    .card:hover {
      transform: translateY(-8px);
      box-shadow: 0 14px 28px rgba(0, 0, 0, 0.3);
    }

    .card img {
      width: 100%;
      height: 190px;
      object-fit: cover;
      transition: transform 0.4s ease;
    }

    .card:hover img {
      transform: scale(1.08);
    }

    .price {
      margin-bottom: 6px;
      font-size: 0.95rem;
      color: #444;
    }

    .rating {
      margin-bottom: 12px;
      font-size: 1rem;
      color: #ffa000;
    }

    .card-content {
      padding: 15px;
      text-align: center;
    }

    .card-content h3 {
      margin-bottom: 10px;
      font-size: 1.2rem;
      color: #2e7d32;
    }

    .card-content a button {
      background: linear-gradient(to right, #43a047, #1b5e20);
      color: #fff;
      border: none;
      padding: 10px 0;
      width: 90%;
      border-radius: 25px;
      font-size: 0.95rem;
      font-weight: bold;
      cursor: pointer;
      transition: background 0.3s ease;
    }

    .card-content a button:hover {
      background: #2e7d32;
    }

    .footer {
      text-align: center;
      padding: 20px;
      background: #e8f5e9;
      font-size: 0.95rem;
      color: #555;
      margin-top: 40px;
      border-top: 1px solid #c8e6c9;
    }

    @media (max-width: 768px) {
      header {
        flex-direction: column;
        align-items: flex-start;
        gap: 10px;
      }

      nav {
        flex-wrap: wrap;
        justify-content: center;
        width: 100%;
      }

      .card {
        width: 100%;
      }

      .homestays {
        padding: 20px;
        gap: 20px;
      }

      h1 {
        font-size: 2rem;
      }
    }
  </style>
</head>
<body>

  <header>
    <div class="logo">FindMyHomestay</div>
    <nav>
      <a href="homee.html">Home</a>
      <a href="Status.php">Status</a>
    </nav>
  </header>

  <h1>HomeStays in Udupi</h1>

  <div class="homestays">
    <?php
    if ($result->num_rows > 0) {
      while ($row = $result->fetch_assoc()) {
        ?>
        <div class="card">
          <img src="farmhouse_admin/admin/uploads/<?php echo htmlspecialchars($row['image']); ?>" alt="<?php echo htmlspecialchars($row['name']); ?>">
          <div class="card-content">
            <h3><?php echo htmlspecialchars($row['name']); ?></h3>
            <p class="price">₹<?php echo htmlspecialchars($row['price']); ?> per person</p>
            <p class="rating">★★★★☆</p>
<a href="athithi.php?id=<?= $row['id'] ?>" class="btn" style="display:inline-block;background:linear-gradient(to right,#43a047,#1b5e20);color:#fff;padding:10px 20px;border-radius:25px;text-decoration:none;font-weight:bold;transition:background 0.3s ease;">Details</a>




          </div>
        </div>
        <?php
      }
    } else {
      echo "<p style='text-align:center;'>No homestays found in Udupi.</p>";
    }
    ?>
  </div>

  <footer class="footer">
    <p>© 2025 Find My Homestay. All rights reserved.</p>
  </footer>

</body>
</html>
