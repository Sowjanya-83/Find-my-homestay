<?php
session_start();

include 'farmhouse_admin/config/config.php';
$admin = new Admin();
$conn = $admin->getConn();

// Receive form data
$farmhouse_id = isset($_POST['farmhouse_id']) ? (int)$_POST['farmhouse_id'] : 0;
$full_name = $_POST['full_name'];
$email = $_POST['email'];
$phone = $_POST['phone'];
$guests = $_POST['guests'];
$checkin = $_POST['checkin_date'];
$checkout = $_POST['checkout_date'];

// Save email in session for status tracking
$_SESSION['user_email'] = $email;

// Check if farmhouse ID is valid
if ($farmhouse_id <= 0) {
    echo "<script>alert('Invalid farmhouse selected.'); window.history.back();</script>";
    exit;
}

// Get admin_id of this farmhouse
$stmtAdmin = $conn->prepare("SELECT admin_id FROM farmhouses WHERE id = ?");
$stmtAdmin->bind_param("i", $farmhouse_id);
$stmtAdmin->execute();
$resultAdmin = $stmtAdmin->get_result();
$rowAdmin = $resultAdmin->fetch_assoc();
$admin_id = $rowAdmin ? $rowAdmin['admin_id'] : 0;

// Insert booking
$stmt = $conn->prepare("INSERT INTO book (farmhouse_id, full_name, email, phone, guests, checkin_date, checkout_date, status)
VALUES (?, ?, ?, ?, ?, ?, ?, 'Pending')");

$stmt->bind_param("isssiss", $farmhouse_id, $full_name, $email, $phone, $guests, $checkin, $checkout);




if ($stmt->execute()) {
    $booking_id = $stmt->insert_id;
    $_SESSION['booking_id'] = $booking_id;
    $_SESSION['farmhouse_id'] = $farmhouse_id;
    echo "<script>alert('Booking submitted successfully!'); window.location='status.php';</script>";
} else {
    echo "<script>alert('Booking failed!'); window.history.back();</script>";
}
?>
